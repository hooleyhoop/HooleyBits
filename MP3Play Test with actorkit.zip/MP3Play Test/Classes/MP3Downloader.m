//
//  MP3Downloader.m
//  ActorKitTest
//
//  Created by steve hooley on 18/06/2009.
//  Copyright 2009 BestBefore Ltd. All rights reserved.
//

#import "MP3Downloader.h"
#import "PLActorRPCProxy.h"
#import "ActorKit.h"
#import "HooAudioStreamer.h"
#import <CFNetwork/CFNetwork.h>

#define v2_CFReadStream

@implementation MP3Downloader

@synthesize delegate = _delegate;

#ifdef v2_CFReadStream
#pragma CFReadStream stuff
- (void)readBufferFromStream:(CFReadStreamRef)stream {

	UInt8 bytes[kAQBufSize];
	CFIndex length;
	
	//
	// Read the bytes from the stream
	//
	length = CFReadStreamRead(stream, bytes, kAQBufSize);
	if( length==0 || length==-1 ) 
		return;
	
	[self connection:nil didReceiveData:[NSData dataWithBytes:bytes length:length]];
}

//
// handleReadFromStream:eventType:data:
//
// Reads data from the network file stream into the AudioFileStream
//
// Parameters:
//    aStream - the network file stream
//    eventType - the event which triggered this method
//
- (void)handleReadFromStream:(CFReadStreamRef)aStream eventType:(CFStreamEventType)eventType {
	
	if( eventType==kCFStreamEventErrorOccurred ) {
		NSLog(@"kCFStreamEventErrorOccurred");
		[self connection:nil didFailWithError:nil];

	} else if( eventType==kCFStreamEventEndEncountered ) {

		[self readBufferFromStream:aStream];
		[self connectionDidFinishLoading:nil];

	} else if( eventType==kCFStreamEventHasBytesAvailable )
	{
		[self readBufferFromStream:aStream];
	}
}

//
// ReadStreamCallBack
//
// This is the callback for the CFReadStream from the network connection. This
// is where all network data is passed to the AudioFileStream.
//
// Invoked when an error occurs, the stream ends or we have data to read.
//
void ASReadStreamCallBack ( CFReadStreamRef aStream, CFStreamEventType eventType, void* inClientInfo) {
	MP3Downloader* downloader = (MP3Downloader *)inClientInfo;
	[downloader handleReadFromStream:aStream eventType:eventType];
}
#endif

- (id)init {

	if((self=[super init])==nil)
		return nil;

	// Launch our actor
	id proxy = [[PLActorRPCProxy alloc] initWithTarget: self];
	[self release];
	return proxy;
}

- (void)dealloc {

	[super dealloc];
}

// Method is called asynchronously
- (oneway void)downloadURL:(NSURL *)anURL {
	
	_downloaderThread = [NSThread currentThread];
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	NSAssert(_delegate!=nil, @"hmm");

#ifdef v2_CFReadStream
	//
	// Create the GET request
	//
	CFHTTPMessageRef message= CFHTTPMessageCreateRequest(NULL, (CFStringRef)@"GET", (CFURLRef)anURL, kCFHTTPVersion1_1);
	CFReadStreamRef stream = CFReadStreamCreateForHTTPRequest(NULL, message);
	CFRelease(message);
	
	// -- TODO --
	// -- check for error CFReadStreamGetError -- //

	//
	// Open the stream
	//
	if(!CFReadStreamOpen(stream)) {	
		CFRelease(stream);
		NSLog(@"failed - pop up an alert! clean up!");
		return;
	}
	
	//
	// Set our callback function to receive the data
	//
	CFStreamClientContext context = {0, self, NULL, NULL, NULL};
	CFReadStreamSetClient( stream, kCFStreamEventHasBytesAvailable | kCFStreamEventErrorOccurred | kCFStreamEventEndEncountered, ASReadStreamCallBack,  &context);
	CFReadStreamScheduleWithRunLoop( stream, CFRunLoopGetCurrent(), kCFRunLoopCommonModes );

#else
	
	// Use NSURLConnection instead of CFReadStream
	NSURLRequest *request = [NSURLRequest requestWithURL:anURL];
	NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];

#endif
	
	// Loop forever, receiving messages
	while( !_streamShouldFinish )
	{
		NSAutoreleasePool *innerPool = [[NSAutoreleasePool alloc] init];
		if(_failed){
			// error downloading..
			[_delegate stopPlayingAudioWithConnectionError];
			[innerPool release];
			break;
		}
	
		NSRunLoop* myRunLoop = [NSRunLoop currentRunLoop];
		[myRunLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:1.0]];
	
		[innerPool release];
	}
	NSLog(@"ECHO killing download actor");

#ifdef v2_CFReadStream
	CFReadStreamClose(stream);
	CFRelease(stream);
#else
	[connection cancel];
	[connection release];
	connection = nil;
#endif

	[pool release];
}
	 
- (NSCachedURLResponse *)connection:(NSURLConnection *)connection willCacheResponse:(NSCachedURLResponse *)cachedResponse {
	return nil;
}

- (void)connection:(NSURLConnection *)inConnection didReceiveData:(NSData *)data {
	
	NSAssert( _downloaderThread==[NSThread currentThread], @"oops wrong thread");

	OSErr err=0;
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	err = [_delegate parseAudioBytes:data];
	[pool release];

	// our custom error number
	if( err==16 ) {
		[inConnection cancel];
		_streamShouldFinish=YES;
		NSLog(@"Finishing!");
	} else if( err ) {
		
		_failed = YES;
	}
}

- (void)connectionDidFinishLoading:(NSURLConnection *)inConnection {
	
	NSAssert( _downloaderThread==[NSThread currentThread], @"oops wrong thread");

	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	[_delegate connectionFinishedLoading];
	[pool release];
	
	_streamShouldFinish = YES;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	
	NSAssert( _downloaderThread==[NSThread currentThread], @"oops wrong thread");
	_failed = YES;
}

- (void)stopIfNeeded {
	
	NSAssert( _downloaderThread==[NSThread currentThread], @"oops wrong thread");

	_delegate = nil;
	_streamShouldFinish = YES;
	NSLog(@"**** Yaya!!!! ***");
}

@end
